package minegame159.meteorclient.gui.widgets;

public interface WRoot {
}
