package minegame159.meteorclient.utils;

public enum Dimension {
    Overworld,
    Nether,
    End
}
