package minegame159.meteorclient.mixininterface;

import net.minecraft.block.Block;

import java.util.Set;

public interface IBlockEntityType {
    Set<Block> getBlocks();
}
