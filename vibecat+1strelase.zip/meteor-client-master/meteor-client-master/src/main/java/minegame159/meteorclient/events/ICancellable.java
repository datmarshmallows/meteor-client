package minegame159.meteorclient.events;

public interface ICancellable extends me.zero.alpine.event.type.ICancellable {
    void setCancelled(boolean cancelled);
}
