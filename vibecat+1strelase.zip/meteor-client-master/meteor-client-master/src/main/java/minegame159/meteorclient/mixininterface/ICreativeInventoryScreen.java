package minegame159.meteorclient.mixininterface;

public interface ICreativeInventoryScreen {
    int getSelectedTab();
}
