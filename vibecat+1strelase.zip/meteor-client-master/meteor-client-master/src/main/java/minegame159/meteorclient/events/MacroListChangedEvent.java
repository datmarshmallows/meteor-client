package minegame159.meteorclient.events;

public class MacroListChangedEvent {
}
