package minegame159.meteorclient.events;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;

public class DamageEvent {
    public LivingEntity entity;
    public DamageSource source;
}
