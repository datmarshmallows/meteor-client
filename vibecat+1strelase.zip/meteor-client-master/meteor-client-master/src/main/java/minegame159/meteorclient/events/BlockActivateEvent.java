package minegame159.meteorclient.events;

import net.minecraft.block.BlockState;

public class BlockActivateEvent {
    public BlockState blockState;
}
