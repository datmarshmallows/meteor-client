package minegame159.meteorclient.mixininterface;

import baritone.api.utils.Rotation;

public interface ILookBehavior {
    Rotation getTarget();
}
