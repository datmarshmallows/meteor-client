package minegame159.meteorclient.mixininterface;

public interface IPlayerMoveC2SPacket {
    void setY(double y);
    void setOnGround(boolean onGround);
}
