package minegame159.meteorclient.mixininterface;

import net.minecraft.util.math.ChunkSectionPos;

public interface IChunkDeltaUpdateS2CPacket {
    ChunkSectionPos getChunkPos();
}
