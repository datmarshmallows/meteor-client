package minegame159.meteorclient.events;

import net.minecraft.text.Text;

public class GameDisconnectedEvent {
    public Text disconnectReason;
}
