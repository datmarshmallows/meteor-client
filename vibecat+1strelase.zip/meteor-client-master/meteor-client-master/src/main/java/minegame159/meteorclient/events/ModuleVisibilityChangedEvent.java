package minegame159.meteorclient.events;

import minegame159.meteorclient.modules.ToggleModule;

public class ModuleVisibilityChangedEvent {
    public ToggleModule module;
}
