package minegame159.meteorclient.utils;

public enum AlignmentX {
    Left, Center, Right
}
