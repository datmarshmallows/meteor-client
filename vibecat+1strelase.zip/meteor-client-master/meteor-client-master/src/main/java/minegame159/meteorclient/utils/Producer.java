package minegame159.meteorclient.utils;

public interface Producer<T> {
    T create();
}
