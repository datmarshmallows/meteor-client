package minegame159.meteorclient.events;

public class CharTypedEvent extends Cancellable {
    public char c;
}
