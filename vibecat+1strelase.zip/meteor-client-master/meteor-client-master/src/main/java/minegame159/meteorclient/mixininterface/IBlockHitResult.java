package minegame159.meteorclient.mixininterface;

import net.minecraft.util.math.Direction;

public interface IBlockHitResult {
    void setSide(Direction direction);
}
