package minegame159.meteorclient.utils;

public class UuidNameHistoryResponseItem {
    public String name;
}
