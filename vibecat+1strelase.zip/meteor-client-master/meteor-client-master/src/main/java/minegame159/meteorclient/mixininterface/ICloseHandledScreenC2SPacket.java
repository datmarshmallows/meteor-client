package minegame159.meteorclient.mixininterface;

public interface ICloseHandledScreenC2SPacket {
    int getSyncId();
}
