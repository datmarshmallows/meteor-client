package minegame159.meteorclient.events;

import net.minecraft.item.ItemStack;

public class DropItemsEvent {
    public ItemStack itemStack;
}
