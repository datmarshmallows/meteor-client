package minegame159.meteorclient.mixininterface;

public interface IKeyBinding {
    void setPressed(boolean pressed);
}
