package minegame159.meteorclient.mixininterface;

public interface IHorseBaseEntity {
    void setSaddled(boolean saddled);
}
