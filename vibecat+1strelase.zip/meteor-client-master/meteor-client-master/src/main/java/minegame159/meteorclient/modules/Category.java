package minegame159.meteorclient.modules;

public enum Category {
    Combat,
    Player,
    Movement,
    Render,
    Misc
}
