package minegame159.meteorclient.mixininterface;

import net.minecraft.client.font.TextHandler;

public interface ITextHandler {
    TextHandler.WidthRetriever getWidthRetriever();
}
