package minegame159.meteorclient.utils;

public enum AlignmentY {
    Top, Center, Bottom
}
