package minegame159.meteorclient.events;

public class SendMessageEvent {
    public String msg;
}
