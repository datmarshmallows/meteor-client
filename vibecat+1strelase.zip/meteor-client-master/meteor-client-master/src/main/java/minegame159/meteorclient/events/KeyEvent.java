package minegame159.meteorclient.events;

import minegame159.meteorclient.utils.KeyAction;

public class KeyEvent extends Cancellable {
    public int key;
    public KeyAction action;
}
