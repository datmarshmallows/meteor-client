package minegame159.meteorclient.events;

import net.minecraft.client.sound.SoundInstance;

public class PlaySoundEvent extends Cancellable {
    public SoundInstance sound;
}
