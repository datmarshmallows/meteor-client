package minegame159.meteorclient.events;

import minegame159.meteorclient.modules.Module;

public class ModuleBindChangedEvent {
    public Module module;
}
