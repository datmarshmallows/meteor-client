package minegame159.meteorclient.accounts;

public enum AccountType {
    Cracked,
    Premium,
    TheAltening
}
