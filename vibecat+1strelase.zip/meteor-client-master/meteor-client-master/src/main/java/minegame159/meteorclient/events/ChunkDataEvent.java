package minegame159.meteorclient.events;

import net.minecraft.world.chunk.WorldChunk;

public class ChunkDataEvent {
    public WorldChunk chunk;
}
