package minegame159.meteorclient.events;

import net.minecraft.entity.Entity;

public class EntityRemovedEvent {
    public Entity entity;
}
