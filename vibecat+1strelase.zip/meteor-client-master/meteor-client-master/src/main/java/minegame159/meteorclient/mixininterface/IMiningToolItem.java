package minegame159.meteorclient.mixininterface;

import net.minecraft.block.Block;

public interface IMiningToolItem {
    boolean isEffectiveOn(Block block);
}
