package minegame159.meteorclient.mixininterface;

public interface IBufferBuilder {
    boolean isBuilding();
}
