package minegame159.meteorclient.events;

import net.minecraft.entity.Entity;

public class EntityAddedEvent {
    public Entity entity;
}
