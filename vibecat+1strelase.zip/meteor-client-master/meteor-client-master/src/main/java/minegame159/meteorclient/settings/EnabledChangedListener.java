package minegame159.meteorclient.settings;

public interface EnabledChangedListener {
    void onEnabledChanged(SettingGroup settingGroup);
}
