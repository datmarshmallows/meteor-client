package minegame159.meteorclient.events;

import net.minecraft.client.gui.screen.Screen;

public class OpenScreenEvent extends Cancellable {
    public Screen screen;
}
