package minegame159.meteorclient.events.packets;

import net.minecraft.network.packet.s2c.play.ScreenHandlerSlotUpdateS2CPacket;

public class ContainerSlotUpdateEvent {
    public ScreenHandlerSlotUpdateS2CPacket packet;
}
