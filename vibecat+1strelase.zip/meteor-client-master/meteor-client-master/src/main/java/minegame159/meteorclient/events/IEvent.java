package minegame159.meteorclient.events;

public interface IEvent {
}
