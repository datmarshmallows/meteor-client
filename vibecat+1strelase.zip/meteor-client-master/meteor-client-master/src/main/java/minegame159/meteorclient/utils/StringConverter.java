package minegame159.meteorclient.utils;

public interface StringConverter<T> {
    T convert(String string);
}
