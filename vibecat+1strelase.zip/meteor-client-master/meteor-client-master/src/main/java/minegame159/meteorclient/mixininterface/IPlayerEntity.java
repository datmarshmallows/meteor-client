package minegame159.meteorclient.mixininterface;

import net.minecraft.entity.player.PlayerInventory;

public interface IPlayerEntity {
    void setInventory(PlayerInventory inventory);
}
