package minegame159.meteorclient.modules.render.hud.modules;

import minegame159.meteorclient.Config;
import minegame159.meteorclient.modules.render.hud.HUD;

public class WatermarkHud extends DoubleTextHudModule {
    public WatermarkHud(HUD hud) {
        super(hud, "watermark", "Show off your goofy ass client.", "VibeCat+ ");
    }

    @Override
    protected String getRight() {
        return Config.INSTANCE.version.getOriginalString();
    }
}
