package minegame159.meteorclient.events;

import net.minecraft.item.ItemStack;

public class PickItemsEvent {
    public ItemStack itemStack;
    public int count;
}
