package minegame159.meteorclient.modules.player;

import minegame159.meteorclient.modules.Category;
import minegame159.meteorclient.modules.ToggleModule;

public class LiquidInteract extends ToggleModule {
    public LiquidInteract() {
        super(Category.Player, "liquid-interact", "Allows you to interact with liquids.");
    }
}
