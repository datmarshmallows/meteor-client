package minegame159.meteorclient.mixininterface;

public interface IStatusEffectInstance {
    void setDuration(int duration);

    void setAmplifier(int amplifier);
}
