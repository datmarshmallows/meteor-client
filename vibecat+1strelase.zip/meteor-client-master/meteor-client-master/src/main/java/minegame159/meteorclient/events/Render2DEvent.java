package minegame159.meteorclient.events;

public class Render2DEvent {
    public int screenWidth, screenHeight;
    public float tickDelta;
}
