package minegame159.meteorclient.utils;

public class NbtException extends RuntimeException {
}
